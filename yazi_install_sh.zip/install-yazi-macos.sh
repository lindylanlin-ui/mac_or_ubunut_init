#!/usr/bin/env bash
# Install Yazi and apply the same macOS-oriented setup used on this machine.
# Run with: bash install-yazi-macos.sh

set -Eeuo pipefail

say() { printf '\n==> %s\n' "$*"; }
warn() { printf '\nWarning: %s\n' "$*" >&2; }

if ! command -v brew >/dev/null 2>&1; then
  say "Homebrew is not installed; starting the official installer"
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

# Make Homebrew available during this run on either Apple Silicon or Intel Macs.
if [[ -x /opt/homebrew/bin/brew ]]; then
  eval "$(/opt/homebrew/bin/brew shellenv)"
elif [[ -x /usr/local/bin/brew ]]; then
  eval "$(/usr/local/bin/brew shellenv)"
fi

say "Installing Yazi and preview/search dependencies"
# Yazi uses `fd` for `s` (search files by name) and `ripgrep` for `S` (search by content).
brew install yazi ffmpeg sevenzip jq fzf fd ripgrep zoxide

# Icons require a Nerd Font.  Installing it is harmless when it already exists;
# select it once in iTerm2/Terminal preferences if your current font lacks icons.
if ! brew list --cask font-meslo-lg-nerd-font >/dev/null 2>&1; then
  brew install --cask font-meslo-lg-nerd-font || warn "Nerd Font could not be installed; Yazi will still work, but icons may be missing."
fi

config_dir="$HOME/.config/yazi"
timestamp="$(date +%Y%m%d-%H%M%S)"
if [[ -d "$config_dir" ]]; then
  backup_dir="$HOME/.config/yazi.backup-$timestamp"
  say "Backing up existing Yazi configuration to $backup_dir"
  mv "$config_dir" "$backup_dir"
fi
mkdir -p "$config_dir"

say "Writing Yazi configuration"
cat > "$config_dir/yazi.toml" <<'EOF'
# macOS-oriented, low-latency Yazi configuration
[mgr]
# Parent directory : current directory : preview
ratio = [2, 4, 3]
sort_by = "natural"
sort_sensitive = false
sort_reverse = false
sort_dir_first = true
sort_translit = false
linemode = "size"
show_hidden = false
show_symlink = true
scrolloff = 5
mouse_events = ["click", "scroll"]
title_format = "Yazi: {cwd}"

[preview]
wrap = "no"
tab_size = 2
image_delay = 30
image_filter = "triangle"
image_quality = 75

[opener]
edit = [
  { run = '${EDITOR:-vim} "$@"', desc = "Edit", block = true, for = "unix" },
]
open = [
  { run = 'open "$@"', desc = "Open", orphan = true, for = "macos" },
]
reveal = [
  { run = 'open -R "$1"', desc = "Reveal in Finder", orphan = true, for = "macos" },
]

[open]
rules = [
  { url = "*.code-workspace", use = ["open", "reveal"] },
  { mime = "text/*", use = ["edit", "reveal"] },
  { mime = "application/{json,ndjson}", use = ["edit", "reveal"] },
  { mime = "*/javascript", use = ["edit", "reveal"] },
  { mime = "inode/empty", use = ["edit", "reveal"] },
  { url = "*", use = ["open", "reveal"] },
]

[tasks]
micro_workers = 5
macro_workers = 4
bizarre_retry = 3
image_alloc = 268435456
image_bound = [10000, 10000]
suppress_preload = false

[which]
sort_by = "none"
sort_sensitive = false
sort_reverse = false
sort_translit = false
EOF

cat > "$config_dir/keymap.toml" <<'EOF'
# Keep Yazi defaults and add quick directory jumps.
[[mgr.prepend_keymap]]
on = [ "g", "h" ]
run = "cd ~"
desc = "Go to Home"

[[mgr.prepend_keymap]]
on = [ "g", "d" ]
run = "cd ~/Downloads"
desc = "Go to Downloads"

[[mgr.prepend_keymap]]
on = [ "g", "D" ]
run = "cd ~/Documents"
desc = "Go to Documents"
EOF

cat > "$config_dir/theme.toml" <<'EOF'
# Tokyo Night inspired theme for Yazi 26.x
[app]
overall = { bg = "#1a1b26" }

[mgr]
cwd = { fg = "#7aa2f7", bold = true }
find_keyword = { fg = "#e0af68", bold = true, italic = true, underline = true }
find_position = { fg = "#bb9af7", bg = "reset", bold = true }
symlink_target = { fg = "#565f89", italic = true }
marker_copied = { fg = "#9ece6a", bg = "#9ece6a" }
marker_cut = { fg = "#f7768e", bg = "#f7768e" }
marker_marked = { fg = "#7dcfff", bg = "#7dcfff" }
marker_selected = { fg = "#e0af68", bg = "#e0af68" }
count_copied = { fg = "#1a1b26", bg = "#9ece6a", bold = true }
count_cut = { fg = "#1a1b26", bg = "#f7768e", bold = true }
count_selected = { fg = "#1a1b26", bg = "#e0af68", bold = true }
border_symbol = "│"
border_style = { fg = "#3b4261" }

# Yazi 26 uses this section for the current-file indicator.
[indicator]
parent = { fg = "#3b4261" }
current = { fg = "#1a1b26", bg = "#e0af68", bold = true }
preview = { fg = "#bb9af7" }
padding = { open = "▶", close = "◀" }

[tabs]
active = { fg = "#1a1b26", bg = "#7aa2f7", bold = true }
inactive = { fg = "#565f89", bg = "#24283b" }
sep_inner = { open = "", close = "" }
sep_outer = { open = "", close = "" }

[mode]
normal_main = { fg = "#1a1b26", bg = "#7aa2f7", bold = true }
normal_alt = { fg = "#7aa2f7", bg = "#24283b" }
select_main = { fg = "#1a1b26", bg = "#9ece6a", bold = true }
select_alt = { fg = "#9ece6a", bg = "#24283b" }
unset_main = { fg = "#1a1b26", bg = "#f7768e", bold = true }
unset_alt = { fg = "#f7768e", bg = "#24283b" }

[status]
overall = { fg = "#c0caf5", bg = "#1a1b26" }
sep_left = { open = "", close = "" }
sep_right = { open = "", close = "" }
perm_type = { fg = "#7aa2f7" }
perm_read = { fg = "#e0af68" }
perm_write = { fg = "#f7768e" }
perm_exec = { fg = "#9ece6a" }
perm_sep = { fg = "#565f89" }
progress_label = { fg = "#c0caf5", bold = true }
progress_normal = { fg = "#7aa2f7", bg = "#3b4261" }
progress_error = { fg = "#f7768e", bg = "#3b4261" }

[input]
border = { fg = "#7aa2f7" }
title = { fg = "#c0caf5" }
value = { fg = "#e0af68" }
selected = { reversed = true }

[pick]
border = { fg = "#7aa2f7" }
active = { fg = "#bb9af7", bold = true }
inactive = { fg = "#565f89" }

[confirm]
border = { fg = "#f7768e" }
title = { fg = "#c0caf5", bold = true }
body = { fg = "#c0caf5" }
list = { fg = "#c0caf5" }
btn_yes = { fg = "#1a1b26", bg = "#9ece6a", bold = true }
btn_no = { fg = "#1a1b26", bg = "#f7768e", bold = true }
btn_labels = [ "Confirm", "Cancel" ]

[tasks]
border = { fg = "#7aa2f7" }
title = { fg = "#c0caf5" }
hovered = { fg = "#bb9af7", underline = true }

[help]
on = { fg = "#bb9af7" }
run = { fg = "#7dcfff" }
desc = { fg = "#9ece6a" }
hovered = { reversed = true, bold = true }
footer = { fg = "#565f89", bg = "#1a1b26" }

[filetype]
rules = [
  { url = "*", is = "orphan", fg = "#f7768e", crossed = true },
  { url = "*", is = "exec", fg = "#9ece6a", bold = true },
  { url = "*/", fg = "#7aa2f7", bold = true },
  { mime = "text/*", fg = "#c0caf5" },
  { url = "*", fg = "#c0caf5" },
]

[icon]
prepend_dirs = [
  { name = ".config", text = "", fg = "#7aa2f7" },
  { name = ".git", text = "", fg = "#ff9e64" },
  { name = "Desktop", text = "", fg = "#7aa2f7" },
  { name = "Documents", text = "󰈙", fg = "#7dcfff" },
  { name = "Downloads", text = "", fg = "#9ece6a" },
  { name = "Pictures", text = "", fg = "#bb9af7" },
  { name = "Music", text = "", fg = "#7dcfff" },
]
EOF

cat > "$config_dir/init.lua" <<'EOF'
-- Intentionally minimal: use Yazi's built-in behaviour and previewers.
EOF

cat > "$config_dir/shell.zsh" <<'EOF'
# `yazi` is a child process and cannot change zsh's working directory itself.
# This wrapper returns the shell to the last directory visited in Yazi.
function yazi() {
  local tmp cwd exit_code
  tmp="$(mktemp -t yazi-cwd.XXXXXX)" || return 1

  command yazi --cwd-file="$tmp" "$@"
  exit_code=$?
  if [[ -s "$tmp" ]]; then
    IFS= read -r cwd < "$tmp" || true
    [[ -n "$cwd" && "$cwd" != "$PWD" ]] && builtin cd -- "$cwd"
  fi
  rm -f -- "$tmp"
  return "$exit_code"
}

function y() {
  yazi "$@"
}
EOF

zshrc="$HOME/.zshrc"
touch "$zshrc"
source_line='[ -f "$HOME/.config/yazi/shell.zsh" ] && source "$HOME/.config/yazi/shell.zsh"'
if grep -Eq '^[[:space:]]*function[[:space:]]+yazi[[:space:]]*\(\)' "$zshrc"; then
  say "Skipping ~/.zshrc Yazi wrapper hook because function yazi() already exists"
elif ! grep -Fqx "$source_line" "$zshrc"; then
  say "Enabling Yazi directory handoff in ~/.zshrc"
  printf '\n# Yazi: return to the last visited directory on exit.\n%s\n' "$source_line" >> "$zshrc"
fi

say "Done"
say "Yazi file search is available with 's' (fd) and content search with 'S' (ripgrep)"
printf '%s\n' "Open a new terminal (or run: source ~/.zshrc), then launch Yazi with: yazi"
printf '%s\n' "Use lowercase q to quit; your terminal will stay in Yazi's last directory."
printf '%s\n' "For icons, choose 'MesloLGS Nerd Font' in iTerm2/Terminal's font settings if needed."
