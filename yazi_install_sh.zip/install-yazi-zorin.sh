#!/usr/bin/env bash
# Zorin OS / Ubuntu setup: installs current Yazi from its official Cargo path
# and applies the same layout, theme, keybindings, and cwd handoff as macOS.
# Run with: bash install-yazi-zorin.sh

set -Eeuo pipefail

say() { printf '\n==> %s\n' "$*"; }
warn() { printf '\nWarning: %s\n' "$*" >&2; }

if ! command -v apt-get >/dev/null 2>&1; then
  printf '%s\n' "This installer is for Zorin OS / Ubuntu / Debian systems." >&2
  exit 1
fi

say "Installing system dependencies"
sudo apt-get update
sudo apt-get install -y \
  build-essential pkg-config libssl-dev curl ca-certificates git \
  file vim xdg-utils unzip fontconfig \
  ffmpeg p7zip-full jq poppler-utils fd-find ripgrep fzf zoxide \
  imagemagick chafa xclip

say "Making Debian's fdfind available as fd for Yazi"
mkdir -p "$HOME/.local/bin"
if command -v fdfind >/dev/null 2>&1; then
  ln -sf "$(command -v fdfind)" "$HOME/.local/bin/fd"
else
  warn "fdfind is unavailable; Yazi's 's' search will not work until fd/fdfind is installed."
fi

# Optional dependencies differ slightly between Ubuntu/Zorin releases.
sudo apt-get install -y resvg 2>/dev/null || warn "resvg is unavailable in this release; SVG previews will use Yazi's fallback."

say "Installing Meslo Nerd Font for file icons"
font_dir="$HOME/.local/share/fonts/MesloLGS-Nerd-Font"
mkdir -p "$font_dir"
font_archive="$(mktemp -t meslo-nerd-font.XXXXXX.zip)"
curl -fL --retry 3 -o "$font_archive" "https://github.com/ryanoasis/nerd-fonts/releases/latest/download/Meslo.zip"
unzip -oq "$font_archive" -d "$font_dir"
rm -f "$font_archive"
fc-cache -f "$font_dir"

if ! command -v cargo >/dev/null 2>&1; then
  say "Installing the Rust toolchain required by Yazi's official installer"
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal
fi
# shellcheck disable=SC1090
source "$HOME/.cargo/env"

say "Installing the current Yazi release"
cargo install --force yazi-build

config_dir="$HOME/.config/yazi"
timestamp="$(date +%Y%m%d-%H%M%S)"
if [[ -d "$config_dir" ]]; then
  backup_dir="$HOME/.config/yazi.backup-$timestamp"
  say "Backing up existing configuration to $backup_dir"
  mv "$config_dir" "$backup_dir"
fi
mkdir -p "$config_dir"

say "Writing Yazi configuration"
cat > "$config_dir/yazi.toml" <<'EOF'
# Zorin OS / Linux configuration
[mgr]
# Parent directory : current directory : preview
ratio = [2, 4, 3]
sort_by = "natural"
sort_sensitive = false
sort_reverse = false
sort_dir_first = true
sort_translit = false
linemode = "size"
show_hidden = false
show_symlink = true
scrolloff = 5
mouse_events = ["click", "scroll"]
title_format = "Yazi: {cwd}"

[preview]
wrap = "no"
tab_size = 2
image_delay = 30
image_filter = "triangle"
image_quality = 75

[opener]
edit = [
  { run = '${EDITOR:-vim} "$@"', desc = "Edit", block = true, for = "unix" },
]
open = [
  { run = 'xdg-open "$@"', desc = "Open", orphan = true, for = "linux" },
]
reveal = [
  { run = 'xdg-open "$(dirname "$1")"', desc = "Open containing folder", orphan = true, for = "linux" },
]

[open]
rules = [
  { url = "*.code-workspace", use = ["open", "reveal"] },
  { mime = "text/*", use = ["edit", "reveal"] },
  { mime = "application/{json,ndjson}", use = ["edit", "reveal"] },
  { mime = "*/javascript", use = ["edit", "reveal"] },
  { mime = "inode/empty", use = ["edit", "reveal"] },
  { url = "*", use = ["open", "reveal"] },
]

[tasks]
micro_workers = 5
macro_workers = 4
bizarre_retry = 3
image_alloc = 268435456
image_bound = [10000, 10000]
suppress_preload = false

[which]
sort_by = "none"
sort_sensitive = false
sort_reverse = false
sort_translit = false
EOF

cat > "$config_dir/keymap.toml" <<'EOF'
[[mgr.prepend_keymap]]
on = [ "g", "h" ]
run = "cd ~"
desc = "Go to Home"

[[mgr.prepend_keymap]]
on = [ "g", "d" ]
run = "cd ~/Downloads"
desc = "Go to Downloads"

[[mgr.prepend_keymap]]
on = [ "g", "D" ]
run = "cd ~/Documents"
desc = "Go to Documents"
EOF

cat > "$config_dir/theme.toml" <<'EOF'
# Tokyo Night-inspired theme with a highly visible current-file cursor.
[app]
overall = { bg = "#1a1b26" }

[mgr]
cwd = { fg = "#7aa2f7", bold = true }
find_keyword = { fg = "#e0af68", bold = true, italic = true, underline = true }
find_position = { fg = "#bb9af7", bg = "reset", bold = true }
symlink_target = { fg = "#565f89", italic = true }
marker_copied = { fg = "#9ece6a", bg = "#9ece6a" }
marker_cut = { fg = "#f7768e", bg = "#f7768e" }
marker_marked = { fg = "#7dcfff", bg = "#7dcfff" }
marker_selected = { fg = "#e0af68", bg = "#e0af68" }
count_copied = { fg = "#1a1b26", bg = "#9ece6a", bold = true }
count_cut = { fg = "#1a1b26", bg = "#f7768e", bold = true }
count_selected = { fg = "#1a1b26", bg = "#e0af68", bold = true }
border_symbol = "│"
border_style = { fg = "#3b4261" }

[indicator]
parent = { fg = "#3b4261" }
current = { fg = "#1a1b26", bg = "#e0af68", bold = true }
preview = { fg = "#bb9af7" }
padding = { open = "▶", close = "◀" }

[tabs]
active = { fg = "#1a1b26", bg = "#7aa2f7", bold = true }
inactive = { fg = "#565f89", bg = "#24283b" }
sep_inner = { open = "", close = "" }
sep_outer = { open = "", close = "" }

[mode]
normal_main = { fg = "#1a1b26", bg = "#7aa2f7", bold = true }
normal_alt = { fg = "#7aa2f7", bg = "#24283b" }
select_main = { fg = "#1a1b26", bg = "#9ece6a", bold = true }
select_alt = { fg = "#9ece6a", bg = "#24283b" }
unset_main = { fg = "#1a1b26", bg = "#f7768e", bold = true }
unset_alt = { fg = "#f7768e", bg = "#24283b" }

[status]
overall = { fg = "#c0caf5", bg = "#1a1b26" }
sep_left = { open = "", close = "" }
sep_right = { open = "", close = "" }
perm_type = { fg = "#7aa2f7" }
perm_read = { fg = "#e0af68" }
perm_write = { fg = "#f7768e" }
perm_exec = { fg = "#9ece6a" }
perm_sep = { fg = "#565f89" }
progress_label = { fg = "#c0caf5", bold = true }
progress_normal = { fg = "#7aa2f7", bg = "#3b4261" }
progress_error = { fg = "#f7768e", bg = "#3b4261" }

[input]
border = { fg = "#7aa2f7" }
title = { fg = "#c0caf5" }
value = { fg = "#e0af68" }
selected = { reversed = true }

[pick]
border = { fg = "#7aa2f7" }
active = { fg = "#bb9af7", bold = true }
inactive = { fg = "#565f89" }

[confirm]
border = { fg = "#f7768e" }
title = { fg = "#c0caf5", bold = true }
body = { fg = "#c0caf5" }
list = { fg = "#c0caf5" }
btn_yes = { fg = "#1a1b26", bg = "#9ece6a", bold = true }
btn_no = { fg = "#1a1b26", bg = "#f7768e", bold = true }
btn_labels = [ "Confirm", "Cancel" ]

[filetype]
rules = [
  { url = "*", is = "orphan", fg = "#f7768e", crossed = true },
  { url = "*", is = "exec", fg = "#9ece6a", bold = true },
  { url = "*/", fg = "#7aa2f7", bold = true },
  { mime = "text/*", fg = "#c0caf5" },
  { url = "*", fg = "#c0caf5" },
]

[icon]
prepend_dirs = [
  { name = ".config", text = "", fg = "#7aa2f7" },
  { name = ".git", text = "", fg = "#ff9e64" },
  { name = "Desktop", text = "", fg = "#7aa2f7" },
  { name = "Documents", text = "󰈙", fg = "#7dcfff" },
  { name = "Downloads", text = "", fg = "#9ece6a" },
  { name = "Pictures", text = "", fg = "#bb9af7" },
  { name = "Music", text = "", fg = "#7dcfff" },
]
EOF

cat > "$config_dir/init.lua" <<'EOF'
-- Intentionally minimal: use Yazi's built-in previewers and behaviour.
EOF

cat > "$config_dir/shell.sh" <<'EOF'
# Return the parent shell to the last directory visited in Yazi.
function yazi() {
  local tmp cwd exit_code
  tmp="$(mktemp -t yazi-cwd.XXXXXX)" || return 1

  command yazi --cwd-file="$tmp" "$@"
  exit_code=$?
  if [[ -s "$tmp" ]]; then
    IFS= read -r cwd < "$tmp" || true
    [[ -n "$cwd" && "$cwd" != "$PWD" ]] && builtin cd -- "$cwd"
  fi
  rm -f -- "$tmp"
  return "$exit_code"
}

function y() {
  yazi "$@"
}
EOF

cp "$config_dir/shell.sh" "$config_dir/shell.zsh"

# Configure both common interactive shells so the wrapper works regardless of
# which terminal profile launches bash or zsh.
touch "$HOME/.zshrc" "$HOME/.bashrc" "$HOME/.profile"
cargo_line='[ -f "$HOME/.cargo/env" ] && source "$HOME/.cargo/env"'
path_line='export PATH="$HOME/.local/bin:$PATH"'
yazi_sh_line='[ -f "$HOME/.config/yazi/shell.sh" ] && source "$HOME/.config/yazi/shell.sh"'
yazi_zsh_line='[ -f "$HOME/.config/yazi/shell.zsh" ] && source "$HOME/.config/yazi/shell.zsh"'

grep -Fqx "$path_line" "$HOME/.profile" || printf '\n# User-local binaries for Yazi helpers\n%s\n' "$path_line" >> "$HOME/.profile"
grep -Fqx "$path_line" "$HOME/.bashrc" || printf '\n# User-local binaries for Yazi helpers\n%s\n' "$path_line" >> "$HOME/.bashrc"
grep -Fqx "$path_line" "$HOME/.zshrc" || printf '\n# User-local binaries for Yazi helpers\n%s\n' "$path_line" >> "$HOME/.zshrc"

grep -Fqx "$cargo_line" "$HOME/.bashrc" || printf '\n# Rust / Yazi\n%s\n' "$cargo_line" >> "$HOME/.bashrc"
grep -Fqx "$cargo_line" "$HOME/.zshrc" || printf '\n# Rust / Yazi\n%s\n' "$cargo_line" >> "$HOME/.zshrc"

grep -Fqx "$yazi_sh_line" "$HOME/.bashrc" || printf '%s\n' "$yazi_sh_line" >> "$HOME/.bashrc"
if grep -Eq '^[[:space:]]*function[[:space:]]+yazi[[:space:]]*\(\)' "$HOME/.zshrc"; then
  say "Skipping ~/.zshrc Yazi wrapper hook because function yazi() already exists"
elif ! grep -Fqx "$yazi_zsh_line" "$HOME/.zshrc"; then
  printf '%s\n' "$yazi_zsh_line" >> "$HOME/.zshrc"
fi

say "Done"
printf '%s\n' "Open a new terminal (or source ~/.zshrc or ~/.bashrc), then run: yazi"
printf '%s\n' "Yazi file search uses 's' via fd and content search uses 'S' via ripgrep."
printf '%s\n' "Use lowercase q to exit; the shell will remain in Yazi's last directory."
printf '%s\n' "Set your terminal font to 'MesloLGS Nerd Font' if file icons do not render."
